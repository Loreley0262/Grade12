public class CreatingFileExample {
    public static void main(String[] args) {
        
    }
}
