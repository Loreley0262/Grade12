package UI;

import Tools.mainthing;

public class Main {
    public static void main(String[] args) {
        //mainthing main = new mainthing();
        //Try sample orders

    }
}
