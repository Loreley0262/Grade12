package Tools;

public class Customer {
    String name;
    Address address;
}
