package Tools.Time;

public interface Theticker {
    public void tick();
}
